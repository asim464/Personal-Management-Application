<template>
    <b-card class="dashboard-sq-banner justify-content-end" no-body>
        <b-card-body class="justify-content-end d-flex flex-column">
            <slot></slot>
        </b-card-body>
    </b-card>
</template>
