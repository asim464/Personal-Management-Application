export const payment_types = [
  { value: "Sale", text: "Sale" },
  { value: "Rent", text: "Rent" },
];

export const property_types = [
  { value: "House", text: "House" },
  { value: "Apartment", text: "Apartment" },
  { value: "Gastronomy", text: "Gastronomy" },
  { value: "Industrial", text: "Industrial" },
  { value: "Parking", text: "Parking" },
  { value: "Garage", text: "Garage" },
  { value: "Land", text: "Land" },
];
