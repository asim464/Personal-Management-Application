export const UserRole = {
  SuperAdmin: 0,
  Admin: 1,
  Agent: 2,
  Customer: 3
};
